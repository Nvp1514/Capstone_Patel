﻿Public Class frmMedium
    Private Sub MnuMainMenu_Click(sender As Object, e As EventArgs) Handles mnuMainMenu.Click
        Dim frmFirst As New frmBrainTest

        Hide()
        frmFirst.ShowDialog()
    End Sub

    Private Sub MnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Close()
    End Sub

    Private Sub InstructionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InstructionsToolStripMenuItem.Click
        Dim frmSecond As New frmInstructions

        Hide()
        frmSecond.ShowDialog()
    End Sub

    Private Sub BtnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        Dim correctCount As Integer = 0
        Dim attemptCount As Integer = 0
        Dim objWriter As New IO.StreamWriter("C:\Users\natas\OneDrive\Documents\Brain Test Riddle Game\scoreboard.txt")
        For correctCount = 0 To 1
            If txtAnswer.TextLength < 1 Or txtAnswer.Text < "A" Then
                MsgBox("Enter an Answer for the riddle")
                txtAnswer.Clear()
                txtAnswer.Focus()
            Else
                If txtAnswer.Text.Contains("water") Then
                    lblAnswer.Visible = True
                    lblAnswer.Text = "Your Right !"
                    correctCount += 1
                    If IO.File.Exists("C:\Users\natas\OneDrive\Documents\Brain Test Riddle Game\scoreboard.txt") Then
                        objWriter.WriteLine("The amount of times you got the medium riddle correct is " & Convert.ToString(correctCount))
                    Else
                        MsgBox("The file not available")
                    End If

                Else
                    lblAnswer.Visible = True
                    lblAnswer.Text = "Your Wrong, Try Again"
                    attemptCount += 1
                    If IO.File.Exists("C:\Users\natas\OneDrive\Documents\Brain Test Riddle Game\scoreboard.txt") Then
                        objWriter.WriteLine("The amount of time you attempted the medium riddle is " & Convert.ToString(attemptCount))
                    Else
                        MsgBox("The File is not available")
                    End If
                End If
            End If
        Next
        txtAnswer.Clear()
        txtAnswer.Focus()
        objWriter.Close()
    End Sub



    Private Sub BtnGiveUp_Click(sender As Object, e As EventArgs) Handles btnGiveUp.Click
        Dim objWriter As New IO.StreamWriter("C:\Users\natas\OneDrive\Documents\Brain Test Riddle Game\scoreboard.txt")
        lblAnswer.Visible = True
        lblAnswer.Text = "The correct answer is water !"
        If IO.File.Exists("C:\Users\natas\OneDrive\Documents\Brain Test Riddle Game\scoreboard.txt") Then
            objWriter.WriteLine("The User Gave Up On the Medium Riddle ")
        Else
            MsgBox("The File is not available")
        End If
        objWriter.Close()
    End Sub

    Private Sub frmMedium_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class