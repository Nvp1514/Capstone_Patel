﻿' Program Name: Brain Test Riddle Game
' Author:       Natasha Patel
' Date:         April 23rd, 2024
' Purpose:      Visual Basic Game to Test your Knowledge  


Option Strict On
Public Class frmBrainTest


    Private Sub BtnMedium_Click(sender As Object, e As EventArgs) Handles btnMedium.Click
        Dim frmThird As New frmMedium

        Hide()
        frmThird.ShowDialog()
    End Sub

    Private Sub BtnEasy_Click(sender As Object, e As EventArgs) Handles btnEasy.Click
        Dim frmSecond As New frmEasy

        Hide()
        frmSecond.ShowDialog()
    End Sub

    Private Sub BtnHard_Click(sender As Object, e As EventArgs) Handles btnHard.Click
        Dim frmFourth As New frmHard

        Hide()
        frmFourth.ShowDialog()
    End Sub

    Private Sub MnuInstructions_Click(sender As Object, e As EventArgs) Handles mnuInstructions.Click
        Dim frmFifth As New frmInstructions

        Hide()
        frmFifth.ShowDialog()
    End Sub

    Private Sub MnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Close()
    End Sub

    Private Sub frmBrainTest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
