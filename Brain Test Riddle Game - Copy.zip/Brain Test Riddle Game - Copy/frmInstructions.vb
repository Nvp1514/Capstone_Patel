﻿Public Class frmInstructions
    Private Sub MnuMainMenu_Click(sender As Object, e As EventArgs) Handles mnuMainMenu.Click
        Dim frmFirst As New frmBrainTest

        Hide()
        frmFirst.ShowDialog()
    End Sub

    Private Sub frmInstructions_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class